package com.tcs.billingmicroservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BillingmicroserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
